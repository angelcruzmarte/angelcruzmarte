VOXYFI BRAND KIT
================

Everything you need to represent VOXYFI correctly.

CONTENTS
  /logos          Vector masters (SVG): gradient icon, mono mark, horizontal lockup.
  /icons          App icons & favicons (iOS, Android, watchOS, PWA, .ico).
  /colors         colors.json + colors.css (oklch source of truth + hex).
  /typography     Type guidelines + Geist-Regular.ttf.
  /social         Open Graph, promo & store graphics, plus high-res profile
                  avatar (2048px), transparent marks, and a 2400px share banner.
  /screenshots    App Store / Play Store marketing screenshots (English set).

LOGO USAGE
  - The mark is the "Voice Chevron": two nested chevrons forming a V.
  - Keep clear space around the mark equal to the chevron's stroke width.
  - Do not recolor, rotate, stretch, add shadows, or place the mark on a
    low-contrast background.
  - Use the mono mark (voxyfi-mark-mono.svg) for single-color contexts.
  - The signature gradient runs deep green -> emerald at 135deg.

COLOR
  - Primary gradient: #123f2e -> #10b981. Solid brand green: #176b43.
  - oklch values in colors.css are authoritative; hex are approximations.

More: https://www.voxyfi.com/brand   |   Press: https://www.voxyfi.com/press

(c) VOXYFI. All assets are for representing VOXYFI. Geist is licensed under the
SIL Open Font License.
